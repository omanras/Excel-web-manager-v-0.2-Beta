<?php
include('header.php') ;

if($userID == '1'){
if(isset($_GET['userID'])){	
$userid = $_GET['userID'] ;
if($userid != '1'){
if($userID == '1'){	
if(isset($_POST['move'])){
	$groupname = $_POST['groupname'] ;
	$userid = $_GET['userID'];
	$groupid = "SELECT groupID FROM `users` WHERE groupName='$groupname'" ;
	//Cehck the group admin
	$userc = mysqli_query($conn,"SELECT groupID FROM `users` WHERE groupID='$userid'");
	$check = mysqli_num_rows($userc);
	if($check !=0){
		$error = true ;
		$errormsg = "Can't move group admin ." ;
	}
	if(empty($groupname)){
		$error = true ;
		$errormsg = "Something wrong" ;
	}
	else{
		if($groupname == 'Disabled select'){
			$error = true ;
			$errormsg = "No group selected " ;
		}
		if ( !$error){
			$rowg = mysqli_query($conn,$groupid) ;
			$rowg = mysqli_fetch_row($rowg) ;
			$groupid = $rowg[0] ;
			$query = "UPDATE users SET groupID='$groupid',groupName='$groupname' WHERE userId='$userid'" ;
			$res = mysqli_query($conn,$query);
			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully move user";
			}
			else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
		}
	}
	
}
}
}
if(isset($_POST['edit'])){
	$userid = $_GET['userID'] ;	
	$username = $_POST['username'] ;
	$email = $_POST['email'] ;
	$password = $_POST['password'] ;
	$password2 = $_POST['password2'] ;
	$userq ="SELECT userName,userEmail FROM `users` WHERE userId='$userid'" ;
	$userq = mysqli_query($conn,$userq) ;
	$userq = mysqli_fetch_row($userq) ;
	$email2 = $userq[1] ;
	 
	$username2 = $userq[0]; 	
	if($username2 != $_POST['username']){
	if (empty($username)) {
			$error = true;
			$nameError = "Please enter your full name.";
		} else if (strlen($username) < 3) {
			$error = true;
			$nameError = "Name must have atleat 3 characters.";
		#} else if (!preg_match("/^[a-zA-Z ]+$/",$username)) {
		#	$error = true;
		#	$nameError = "Name must contain alphabets and space.";
		}

			else{
			// check username exist or not
			$query = "SELECT userName FROM users WHERE userName='$username'";
			$result = mysqli_query($conn,$query);
			$count = mysqli_num_rows($result);
			if($count!=0){
				$error = true;
				$nameError = "Provided username is already in use.";
			}
			}
	}
//basic email validation
		if ($email2 != $email){
		if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
			$error = true;
			$emailError = "Please enter valid email address.";
		} else {
			// check email exist or not
			$query = "SELECT userEmail FROM users WHERE userEmail='$email'";
			$result = mysqli_query($conn,$query);
			$count = mysqli_num_rows($result);
			if($count!=0){
				$error = true;
				$emailError = "Provided Email is already in use.";
			}
		}
		}		// password validation
		if (empty($password)){
			$error = true;
			$passError = "Please enter password.";
		} else if(strlen($password) < 6) {
			$error = true;
			$passError = "Password must have atleast 6 characters.";
		}
		else if($password != $password2 ){
			
			$error = true ;
			$passError = "Password not match.";
		
		
		}
		// password encrypt using SHA256();
		$password = hash('sha256', $password);
		// if there's no error, continue to signup
		if( !$error ) {
			
			$query = "UPDATE users SET userName='$username',userEmail='$email',userPass='$password' WHERE userId='$userid'";
			
			$res = mysqli_query($conn,$query);
				
			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully update informations";
				unset($username);
				unset($email);
				unset($password);
				unset($password2);
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
				
		}
		
		
	}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Groups Settings</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
                 <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
						
						<?php
						if($userID == '1'){	
						if($userid != '1'){ ?>
							<form action="<?php echo "edit-user.php?userID=$userid" ; ?> " method="POST">
                            <label for="disabledSelect">Move user to other group</label>
                                            		            <?php
			if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			?>
                                            <div class="form-group">
											
                                                <label for="disabledSelect">Select group</label>
												<span class="text-danger"><?php echo $errormsg; ?></span>
                                                <select id="disabledSelect" class="form-control" name="groupname">
												<option>Disabled select</option>
												<?php
												$q = "SELECT groupName FROM `users` WHERE userId = groupID" ;
												$q = mysqli_query($conn,$q) ;
												while($rowq = mysqli_fetch_array($q)){
													
														echo '<option value="',$rowq[0],'">',$rowq[0],'</option>' ;
													
												} 
												?>
                                                    
                                                </select>
                                            </div>
                                            
                                            <input type="submit" class="btn btn-primary" name="move" value="move">
                                        </fieldset>
                                    </form>
									
									</div>
<?php }} ?>						
				 <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">user informations</h3>
                    </div>
					            <?php
			if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			$userq = "SELECT userName,userEmail FROM `users` WHERE userId='$userid'" ;
			$userq = mysqli_query($conn,$userq) ;
			$rowu = mysqli_fetch_row($userq);
			?>					
				<div class="panel-body">
                        <form method="POST" action="<?php echo "edit-user.php?userID=$userid";?>" autocomplete="off">
                            <fieldset>
							<div class="form-group">
                                    <input class="form-control" placeholder="username" name="username" type="input" value="<?php echo "$rowu[0]" ; ?>" autofocus>
									<span class="text-danger"><?php echo $nameError; ?></span>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" value="<?php echo "$rowu[1]" ; ?>" autofocus>
									<span class="text-danger"><?php echo $emailError; ?></span>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" >
									<span class="text-danger"><?php echo $passError; ?></span>
                                </div>
								<div class="form-group">
                                    <input class="form-control" placeholder="conform password" name="password2" type="password" >
									
                                </div>
                                
                                <!-- Change this to a button or input when using this as a form -->
								<input type="submit" class="btn btn-lg btn-success btn-block" name="edit" value="Send">
                                
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
									</div>
		



<?php
}
}
else{
	echo "Not allow";
}
include('footer.php') ;
?>