<?php
include('header.php') ;
if($userID == '1'){
?>

 <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Groups Settings</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>UserID</th>
                                            <th>GroupID</th>
                                            <th>Group Name</th>
                                            <th>Group Admin</th>
											<th>Settings</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php /*<tr>
                                            <td>1</td>
                                            <td>Mark</td>
                                            <td>Otto</td>
                                            
                                        </tr>
										*/?>
                                       <?php
									   $view = mysqli_query($conn,"SELECT userId,groupID,groupName,userName FROM `users` WHERE userId = groupID") ;
									   
									   while($row = mysqli_fetch_row($view) ){
									   echo '<tr>' ;
									   foreach($row as $key => $value){
										   
										   echo "<td>$value</td>" ;
										   
									   }
									   
									   if($row[0] == $row[1] ){
										   $icon = '<i class="fa fa-gear fa-fw"></i>' ;
										   echo "<td><a  href=\"group-setting.php?groupID=$row[1]\">$icon</td>" ;
									   }
									   echo '</tr>' ;
									   }
									   ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>




<?php
}
else{
	echo "Not allow" ;
}
include('footer.php') ;
?>