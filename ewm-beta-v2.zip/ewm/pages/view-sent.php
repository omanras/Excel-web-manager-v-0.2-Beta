<?php
include('header.php') ;
?>
 <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
					<?php
					if(isset($_GET['msID'])){
						$msID = $_GET['msID'] ;
						$viewms = "SELECT msID,title,message,userSendID,time,sentID FROM `message_t` WHERE msID='$msID' AND userResveID='$userID'";
						$viewms = mysqli_query($conn,$viewms);
						
						$rowms = mysqli_fetch_row($viewms);
						$userv = $rowms[5] ;
						$userms = mysqli_query($conn,"SELECT userName FROM `users` WHERE userId='$userv'") ;
						$userms = mysqli_fetch_row($userms);
					
					?>
                        <h1 class="page-header">Sent Box</h1>
                    </div>
                    <!-- /.col-lg-12 -->
					
                </div>
                <!-- /.row -->
				
            </div>
            <!-- /.container-fluid -->
			 <div class="table-responsive">
                                <table class="table">
                                    <thead>
						<tr>		
					<?php
					 
					$confvalue="return confirm('You Want to delete this message?');";
					$confrm = 'onclick='.'"'.$confvalue.'"' ;
					echo '<td><div><p>',$rowms[4],'</p></div><strong>Title:'.$rowms[1]. '</strong> <div><strong>To:' .$userms[0].'</strong></div><div style="float:right;"> <a href="froward-ms.php?msID=',$msID,'"> Froward </a> </a> <a href="ms-delete.php?msID=',$msID,'" ',$confrm,'> Delete </a></div></td>'; ?>
					</tr>
					<th><strong>Message :</strong>
					<p><?php echo $rowms[2];?></p></th>
								
								</tbody>	
                                </table>
			
        </div>
		
        <!-- /#page-wrapper -->
	
    </div>

<?php
}
include('footer.php');
?>