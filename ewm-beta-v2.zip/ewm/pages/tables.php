<?php
include('header.php');
if($userID == $groupID){
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tables Settings</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
 <div class="panel-body">
                            <div class="table-responsive">
								
								
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>Table Name</th>
                                            
                                            <th>Settings</th>
                                            <th>Delete</th>
											  <?php
									   $view = mysqli_query($conn,"SELECT tablename FROM `table_n` WHERE groupID = '$groupID'") ;
									   
									   while($row = mysqli_fetch_row($view) ){
									   echo '<tr>' ;
									   foreach($row as $key => $value){
										   
										   echo "<td>$value</td>" ;
										   
									   }
									   
									   
										   $icon = '<i class="fa fa-gear fa-fw"></i>' ;
										   $icon2 = '<i class="fa fa-trash-o"></i>' ;
										  
											
										   
										   
										    echo "<td><a  href=\"table-setting.php?tablename=$row[0]\">$icon</td>" ;
										   echo "<td><a  href=\"delete-table.php?tablename=$row[0]\">$icon2</td>" ;
										   
									   echo '</tr>' ;
									   }
									   ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>


<?php
}
include('footer.php');
?>