<?php
include('header.php');
$tablename = $_GET['tablename'];
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);
$form = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'");
if(isset($_GET['AddNew'])){
$tablename = $_GET['tablename'];
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);
$a = array() ;
		$count = 0 ;
		$data='';
			foreach($_POST as $key => $val){
			if($val!='save' && $val != 'save and add'){
				$a[$count] = $val ;
				$data=$data."'$a[$count]'".",";
		   	    
			}
			$count++ ;
	   }		
		$sqlinsert=substr($data,0,-1);

		$Sql_Query = "INSERT INTO `$tablename2`  VALUES ('',$sqlinsert)" ;
		$QueryRes=mysqli_query($conn,$Sql_Query);
if($QueryRes){
	$errTyp = "success" ;
	$errormsg = "Successfully insert informations" ;
		}else{
				$errTyp = "danger";
				$errormsg = "Error can't insert informations ." ;	
		}
		if(isset($_POST['saveadd'])){
			echo "<meta http-equiv=\"refresh\" content=\"3; url=forms.php?tablename=$tablename\" />" ;
		}
		else{
		echo "<meta http-equiv=\"refresh\" content=\"3; url=table-view.php?tablename=$tablename\" />";
	}		
}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add record in : <?php echo $tablename; ?></h1>
                </div>
				</div>
					<?php 
					if ( isset($errTyp) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errormsg; ?>
                </div>
            	</div>
                <?php
			} ?>
				<form action="forms.php?tablename=<?php echo $tablename ; ?>&AddNew" method="POST" enctype="multipart/form-data">
				<?php
				while($formrow = mysqli_fetch_row($form)){
					foreach($formrow as $key => $value){
						if($value == 'idRow'){
							break ;
						}
						echo '<strong>',$value ,':</strong><input class="form-control" type="text" name="',$value,'"> ';
					}
				}
				?>
				<br>
				<input type="submit" class="btn btn-primary" name="save" value="save">
				<input type="submit" class="btn btn-primary" name="saveadd" value="save and add">
				</form>




<?php
include('footer.php');
?>