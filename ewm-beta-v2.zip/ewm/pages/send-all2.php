<?php
include('header.php');
?>

<?php
		if(isset($_GET['send'])){
		$userSendID = $userID ;
		$title = $_POST['title'] ;
		$message = $_POST['message'];
		$groupname = $_POST['groupname'];
		$id = count($groupname) ;
	
		if (count($id) > 0) {
					foreach ($groupname as $id_d) {
					$usercheck = mysqli_query($conn,"SELECT userId,groupID FROM `users` WHERE userId='$id_d' AND groupID='$groupID'");
					$usercheck = mysqli_fetch_row($usercheck) ;
					$useridc = $usercheck[0] ;
					$groupidc = $usercheck[1] ;
					if($groupID == $groupidc){
					$userGroupID = $groupID ; 
					$groupq = "INSERT INTO `message_t` VALUES ('','$userSendID','$userGroupID','$id_d','','$title','$message',CURRENT_TIME()) " ;
					$groupq2 = "INSERT INTO `message_t` VALUES ('','$userSendID','$groupID','$userID','$id_d','$title','$message',CURRENT_TIME()) " ;
					$groupn = mysqli_query($conn,$groupq) ;
					mysqli_query($conn,$groupq2) ;
					}	
					
					else{
				     $errTyp = "danger";
				     $errMSG = "Can't send this message.";
					}
					
					
					
						}
				if ($groupn) {
				$errTyp = "success";
				$errMSG = "Successfully message Send";
				
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
		}
			if ( isset($errMSG) ) {
				
				?>
				<div id="page-wrapper">
				<div class="row">
                <div class="col-lg-12">
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
				</div>
				</div>
				</div>
                <?php
							          
			
			
		
	}
		}
?>

<?php


if(isset($_POST['sendg'])){
	$userSendID = $userID ;
	$userid = $_POST['select'] ;
	$id = count($groupid);
	if(empty($userid)){
		$errTyp = "danger";
		$errMSG = "No user was select";	
		?>
		<div id="page-wrapper">
		     <div class="row">
                <div class="col-lg-12">
				<?php if ( isset($errMSG) ) { ?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
				<?php } 
	}
	else{
?>
<div id="page-wrapper">
         <form action="send-all2.php?send" method="POST">

            <div class="row">
                <div class="col-lg-12">
				<?php if ( isset($errMSG) ) { ?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
				<?php } ?>
                    <h1 class="page-header">Send Message To :</h1>
					<?php 
					if (count($id) > 0) {
						foreach ($userid as $id_d) {
					$groupq = "SELECT userName,userId From `users` WHERE userId='$id_d' AND groupID='$groupID' " ;
					
					$groupn = mysqli_query($conn,$groupq) ;
					$groupname = mysqli_fetch_row($groupn) ;	
					#echo '<p name="groupname[]"><b>To : ', $groupname[0],' </b></p>' ;
					echo '<label><input type="checkbox" name="groupname[]"  value="',$groupname[1],'" checked>',$groupname[0], ' </label><br>' ;
					}
					}
					?>
					  </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="row">
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Message Title</label>
                                            <input class="form-control" name="title">
                                            
                                        </div>


<div>
 <label>Message</label>
    <textarea class="form-control" rows="12" name="message"></textarea>
	

	</div>
	<br>
	<input type="submit" class="btn btn-success" name="send" value="Send">
	</form>
<?php
	}
}
include('footer.php') ;
?>