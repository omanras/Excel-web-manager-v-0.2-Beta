<?php
include('header.php');

?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				
                    <h1 class="page-header">Messages System</h1>
					<div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs">
							<li class="active"><a href="send.php" >Messages System</a>
                                </li>
								<li><a href="inbox.php" >Inbox</a>
                                </li>
							<li><a href="sent-inbox.php" >Sent Box</a>
                                </li>
							<?php if($userID == $groupID){ ?>
                                        <li><a href="broadcast.php">Broadcast Manage</a>
                                        </li>
										<?php } ?>
                                
                            </ul>
							</div>
							
							
				
                </div>
				
                 
									
									
                <!-- /.col-lg-12 -->
				
            </div>
			
					<?php if($userID == $groupID){ ?>
			 <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           
							<form action="send-all.php" method="POST">
                                        <div class="form-group">
										
                                            <label>Groups Admin</label>
											
											<input type="submit" class="btn btn-success" style="float:right;" value="Send Broadcast to selected groups" name="broadcast">
											<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>UserID</th>
                                            <th>User Name</th>
                                            <th>GroupID</th>
                                            <th>GroupName</th>
											<th>Send</th>
											<th>Select</th>
											  <?php
									   $view = mysqli_query($conn,"SELECT userId,userName,groupID,groupName FROM `users` WHERE groupID = userId") ;
									   
									   while($row = mysqli_fetch_row($view) ){
									   echo '<tr>' ;
									   foreach($row as $key => $value){
										   
										   echo "<td>$value</td>" ;
										   
									   }
									   
									   
										   $icon = '<i class="fa fa-envelope-o"></i>' ;
										   echo "<td><a href = \"send-ms.php?userID=$row[0]\" > $icon </a></td>";
										    
										  echo '<td><label><input type="checkbox" name="select[]"  value="',$row[0],'" > </label></td> ' ;
											/*<div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Checkbox 1
                                                </label>
                                            </div>
										   */
										   
										 
										   
									   echo '</tr>' ;
									   }
									   ?>
									  
                                    </tbody>
									
                                </table>
								<input type="submit" class="btn btn-info" style="float:right;" value="Send to selected users" name="sendms">
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
										
                                        </div>
                        </div>
						</form>
						
						   <?php } ?>
                        <!-- /.panel-heading -->
                       	 <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           
							<form action="send-all2.php" method="POST">
                                        <div class="form-group">
										
                                            <label>Group Users</label>
											
											<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>UserID</th>
                                            <th>User Name</th>
											<th>Send</th>
											<th>Select</th>
											  <?php
									   $view = mysqli_query($conn,"SELECT userId,userName FROM `users` WHERE groupID ='$groupID'") ;
									   
									   while($row = mysqli_fetch_row($view) ){
									   echo '<tr>' ;
									   foreach($row as $key => $value){
										   
										   echo "<td>$value</td>" ;
										   
									   }
									   
									   
										   $icon = '<i class="fa fa-envelope-o"></i>' ;
										   echo "<td><a href = \"send-ms.php?userID=$row[0]\" > $icon </a></td>";
										    
										  echo '<td><label><input type="checkbox" name="select[]"  value="',$row[0],'" > </label></td> ' ;
											/*<div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Checkbox 1
                                                </label>
                                            </div>
										   */
										   
										 
										   
									   echo '</tr>' ;
									   }
									   ?>
									  
                                    </tbody>
									
                                </table>
								<input type="submit" class="btn btn-info" style="float:right;" value="Send to selected users" name="sendg">
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
										
                                        </div>
                        </div>
						</form>



<?php

include('footer.php') ;
?>