<?php
include('header.php');
?>

<?php
if(isset($_POST['send'])){
	$userSendID = $userID ;
	$userid = $_GET['userID'] ;
	$title = $_POST['title'] ;
	$message = $_POST['message'] ;
	$userchek = mysqli_query($conn,"SELECT userId,groupID FROM `users` WHERE userId='$userid' ") ;
	$userchek = mysqli_fetch_row($userchek) ;
	$groupid = $userchek[1] ;
	if($userchek[0] == $userchek[1]){
		$sendq = "INSERT INTO `message_t` VALUES ('','$userSendID','$groupid','$userid','','$title','$message',CURRENT_TIME()) " ;
		$sendq2 = "INSERT INTO `message_t` VALUES ('','$userSendID','$groupID','$userID','$userid','$title','$message',CURRENT_TIME()) " ;
		$sendq = mysqli_query($conn,$sendq) ;
		$sendq2 = mysqli_query($conn,$sendq2) ;
		if ($sendq) {
				$errTyp = "success";
				$errMSG = "Successfully message Send";
				
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}
			
		}
	
	else if($userchek[1] == $groupID){
		$sendq = "INSERT INTO `message_t` VALUES ('','$userSendID','$groupid','$userid','','$title','$message',CURRENT_TIME()) " ;
		$sendq2 = "INSERT INTO `message_t` VALUES ('','$userSendID','$groupID','$userID','$userid','$title','$message',CURRENT_TIME()) " ;
		$sendq = mysqli_query($conn,$sendq) ;
		$sendq2 = mysqli_query($conn,$sendq2) ;
			
			if ($sendq) {
				$errTyp = "success";
				$errMSG = "Successfully message Send";
				
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}
			
		}
		else{
			$errTyp = "danger";
			$errMSG = "Can't send this message.";
		}
	}
	


if(isset($_GET['userID'])){
	$userid = $_GET['userID'];
	$username = mysqli_query($conn,"SELECT userId,groupID,userName FROM `users` WHERE userId='$userid'");
	$username = mysqli_fetch_row($username);
	$username = $username[2] ;
	if(empty($userid)){
			$errTyp = "danger";
		$errMSG = "No user was select";	
		?>
		<div id="page-wrapper">
		     <div class="row">
                <div class="col-lg-12">
				<?php if ( isset($errMSG) ) { ?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
				<?php } 
	}
	else{
	
?>
<div id="page-wrapper">
         <form action="<?php echo "send-ms.php?userID=$userid"?>" method="POST">

            <div class="row">
                <div class="col-lg-12">
				<?php if ( isset($errMSG) ) { ?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
				<?php } ?>
                    <h1 class="page-header">Send Message To : <?php echo $username ; ?></h1>
					  </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="row">
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Message Title</label>
                                            <input class="form-control" name="title">
                                            
                                        </div>


<div>
 <label>Message</label>
    <textarea class="form-control" rows="12" name="message"></textarea>
	

	</div>
	<br>
	<input type="submit" class="btn btn-success" name="send" value="Send">
	</form>
<?php }} ?>
	
<?php

include('footer.php');
?>