<?php
include('header.php');
if($userID == $groupID){
$tablename = $_GET['tablename'];	

if(isset($_GET['yes'])){
	$tablename = $_GET['tablename'];
	$tablename2 = $tablename . $groupID ;
	$tablename2 = base64_encode($tablename2);
	if(empty($tablename)){
	$errTyp = "danger";
	$errMSG = "Something wrong try again later.  ";
	}
	else{
		#DROP TABLE `table`
		
		
			
		$delete = mysqli_query($conn,"DROP TABLE `$tablename2`") ;
		
		mysqli_query($conn,"DELETE FROM `table_n` WHERE tablename='$tablename' AND groupID='$groupID'") ;
		if($delete){
			$errTyp = "success" ;
			$errMSG = "Successfully delete table." ;
		}
	}
}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				
                    <h1 class="page-header">Delete table name : <?php echo $tablename ; ?> </h1>
						<?php
					if ( isset($errMSG) ) {
				
				?>
<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
					<?php } ?>
					<div class="col-lg-8">
					<p><h2> if you delete this table all data of this table will deleted , are you want to delete this table "<?php echo $tablename ; ?>" ?</h2></p>
					<a href="<?php echo "home.php" ;?>" class="btn btn-warning">No</a>
					<a href="<?php echo "delete-table.php?tablename=$tablename&yes" ;?>" class="btn btn-info">Yes</a>
					</div>

<?php
}

include('footer.php');
?>