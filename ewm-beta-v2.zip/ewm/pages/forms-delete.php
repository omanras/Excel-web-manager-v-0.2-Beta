<?php
include('header.php') ;
if(isset($_GET['idRow'])){
$idRow = $_GET['idRow'];
$tablename = $_GET['tablename'];
$tablename2 = $tablename.$groupID ;
$tablename2 = base64_encode($tablename2);
if(empty($tablename)){
	$errTyp = "danger";
	$errMSG = "Something went wrong, try again later...";	
}	
else if(empty($idRow)){
	$errTyp = "danger";
	$errMSG = "Something went wrong, try again later...";	
}
else{
	#DELETE FROM `$table` WHERE idRow='$id3'
	$delete = mysqli_query($conn,"DELETE FROM `$tablename2` WHERE idRow='$idRow'");
	if($delete){
		$errTyp = "success";
		$errMSG = "Successfully delete record";
	}
	else{
	$errTyp = "danger";
	$errMSG = "Something went wrong, try again later...";
	}
}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
					<?php if ( isset($errMSG) ) { ?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
				<?php 
				echo "<meta http-equiv=\"refresh\" content=\"0; url=table-view.php?tablename=$tablename\" />";
				} ?>

<?php
}
include('footer.php');
?>