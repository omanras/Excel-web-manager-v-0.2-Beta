<?php
include('header.php');

if(isset($_POST['select'])){
$delete_id = $_POST['select'] ;
$tablename = $_GET['tablename'] ;
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);

if(empty($delete_id)){
				$errTyp = "danger";
				$errMSG = "No value selected";
}
else if(empty($tablename)){
				$errTyp = "danger";
				$errMSG = "No tablename selected";
}
else{
 $id = count($delete_id);
	#echo $id ;
    if (count($id) > 0) {
        foreach ($delete_id as $id_d) {
		  $id_d = htmlspecialchars($id_d) ;
		   $id_d = mysqli_real_escape_string($conn,$id_d);
           $sql    = "DELETE FROM `$tablename2` WHERE idRow='$id_d'";
           $deleteq = mysqli_query($conn,$sql);
        }
    }

if ($deleteq) {
				$errTyp = "success";
				$errMSG = "Successfully Delete Records";
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	 
}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Delete Records </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
<?php
if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
				echo "<meta http-equiv=\"refresh\" content=\"0; url=table-view.php?tablename=$tablename\" />";
			}
			?>

<?php
}
include('footer.php');

?>