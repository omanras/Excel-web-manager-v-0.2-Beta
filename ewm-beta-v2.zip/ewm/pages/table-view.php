<?php
include('header.php');
if(isset($_GET['tablename'])){
$tablename = $_GET['tablename'] ;	
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);	

$h = base64_decode($tablename2);
$page = 0 ; 
#mysqli_num_rows(result);
$nums = mysqli_query($conn,"SELECT * FROM `$tablename2`") ;
$nums = mysqli_num_rows($nums) ;

if(isset($_GET['page'])){
	$page = $_GET['page'] ;
	if(empty($page)){
		$page = 0 ;
	}
}
if(isset($_GET['all'])){
	$view = mysqli_query($conn,"SELECT * FROM `$tablename2`") ;
}
else{
#SELECT * FROM  `$table` LIMIT $offset,20
$offset = $page * 20 ;
$view = mysqli_query($conn,"SELECT * FROM `$tablename2` LIMIT $offset,20") ;
}
?>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				<!-- /.panel-heading -->
		  
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs">
							<li><a href="home.php" >Home</a>
                                </li>
							<?php
							$table = mysqli_query($conn,"SELECT tablename FROM `table_n` WHERE groupID='$groupID'");
							while($tablerow=mysqli_fetch_row($table)){
								if($tablename == $tablerow[0]){
								echo '<li class="active"><a href="table-view.php?tablename=',$tablerow[0],'" >',$tablerow[0],'</a>' ;
                                echo '</li>' ;
								}
								else{
								echo '<li><a href="table-view.php?tablename=',$tablerow[0],'" >',$tablerow[0],'</a>' ;
                                echo '</li>' ;
								}
							}
							?>
                                
                            </ul>
							</div>
						
                    <h1 class="page-header">Table : <?php echo $tablename; ?></h1>
                </div>
				<form action="search.php?tablename=<?php echo $tablename; ?>" method="POST" enctype="multipart/form-data"">
				
										
                                        
                                            <div class="input-group custom-search-form">
                                            <input class="form-control" name="search" placeholder="Search...">
											
                                            <span class="input-group-btn"><button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button></span>
								</div>
                                        </form>
				</div>
				<div class="panel-body">
                           <?php
						   $confvalue="return confirm('You Want to delete this record?');";
						   $confrm = 'onclick='.'"'.$confvalue.'"' ;
						   ?>
								<form action="forms-delete-all.php?tablename=<?php echo $tablename ; ?>" method="POST">
								<a href="<?php echo "forms.php?tablename=$tablename" ;?>" class="btn btn-info">Add Record </a>
							
								 <input type="submit" class="btn btn-danger" value="Delete selected values" style="float:right;" <?php echo $confrm?>>
                                <table id="myTable" class="table" cellspacing="0" width="100%">
                                    <thead>
									<br>
									<div style="float:right;">
									<?php	
							if($nums > 20){
								$nums = $nums / 20 ;
							?>
						<ul class="pagination">
						<?php 
						if($page > 0){
						
						echo '<li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous">' ;
						$pre = $page - 1 ;
						echo '<a href= "',$_PHP_SELF,'?tablename=',$tablename,'&page=',$pre,'"> previous</a></li> '
						?>
						
						<li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous">

						<?php } ?> 
						<?php
						
						
						foreach(range(0,$nums) as $pages){
							#"<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$next\" $styel> Next  Record | </a>";
							if($page == $pages){
							echo '<li class="paginate_button active" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous">' ;
							echo '<a href= "',$_PHP_SELF,'?tablename=',$tablename,'&page=',$pages,'">',$pages,'</a></li><li class="paginate_button " aria-controls="dataTables-example" tabindex="0">' ;	
							}
							else{
							echo '<li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous">' ;
							echo '<a href= "',$_PHP_SELF,'?tablename=',$tablename,'&page=',$pages,'">',$pages,'</a></li><li class="paginate_button " aria-controls="dataTables-example" tabindex="0">' ;
							}
						}
						
						if($page < $nums){
						$next = $page + 1 ;	
						echo '<li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next">' ;
						echo '<a href= "',$_PHP_SELF,'?tablename=',$tablename,'&page=',$next,'">Next</a></li>' ;
							}
							echo '<li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next">' ;
						echo '<a href= "',$_PHP_SELF,'?tablename=',$tablename,'&all">All</a></li></ul>' ;
							}
						?>
								
						
									</div>
									<tr>
									<?php
									$col = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'");
									while($colrow = mysqli_fetch_row($col)){
										foreach($colrow as $key => $value){
											if($value == 'idRow'){
												break ;
											}
											echo "<th>$value</th>" ;
										}
									}
									?>
                                        <th>Edit</th>
										<th>Delete</th>
										<th>Select</th>
											  <?php
									   #$view = mysqli_query($conn,"SELECT * FROM `$tablename2`") ;
									   
									   while($row = mysqli_fetch_array($view) ){
									   $col = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'");
									   echo '<tr> <tfoot>' ;
									   while($row2 = mysqli_fetch_row($col)){  
									   foreach($row2 as $key => $value){
										if($value == 'idRow'){
											break ;
										}
										   echo "<td>$row[$value]</td>" ;
										   
									   }
									   }
									   
										   $icon = '<i class="fa fa-pencil"></i>' ;
										   $icon2 = '<i class="fa fa-trash-o"></i>' ;
										  
											
										   $confvalue="return confirm('You Want to delete this record?');";
											$confrm = 'onclick='.'"'.$confvalue.'"' ;
										   
										    echo "<td><a  href=\"forms-edit.php?tablename=$tablename&idRow=$row[0]\">$icon</td>" ;
										   echo "<td><a  href=\"forms-delete.php?tablename=$tablename&idRow=$row[0]\" $confrm>$icon2</td>" ;
										   echo '<td><label><input type="checkbox" name="select[]"  value="',$row[0],'" > </label></td> ' ;
										   
									   echo '</tr> </tfoot>' ;
									   }
									   ?>
									   
                                    </tbody>
                                </table>
								</form>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
										
                                    </thead>
 

<?php
}
include('footer.php');
?>