<?php
include('header.php');
if($userID == $groupID){
	
#SELECT *  FROM `ewm`.`broadcast_t` WHERE (CONVERT(`brID` USING utf8) LIKE '%admin%' OR CONVERT(`userSendID` USING utf8) LIKE '%admin%' OR CONVERT(`groupName` USING utf8) LIKE '%admin%' OR CONVERT(`title` USING utf8) LIKE '%admin%' OR CONVERT(`message` USING utf8) LIKE '%admin%' OR CONVERT(`time` USING utf8) LIKE '%admin%')

#SELECT * FROM `ewm` .`message_t` WHERE (CONVERT(`msID` USING utf8) LIKE '%hello%' OR CONVERT(`userSendID` USING utf8) LIKE '%hello%' OR CONVERT(`userGroupID` USING utf8) LIKE '%hello%' OR CONVERT(`userResveID` USING utf8) LIKE '%hello%' OR CONVERT(`sentID` USING utf8) LIKE '%hello%' OR CONVERT(`title` USING utf8) LIKE '%hello%' OR CONVERT(`message` USING utf8) LIKE '%hello%' OR CONVERT(`time` USING utf8) LIKE '%hello%' ) AND `userSendID`='1' AND `userResveID`='1'
$tablename = 'message_t' ;
$box = $_GET['box'] ;
if(empty($box)){
	echo "<script>alert('error');</script>" ;
}
else{
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);
$search = $_POST['search'] ;
$cols = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename'");
$a = array() ;
$count = 0 ;
while($colrow = mysqli_fetch_row($cols)){
	foreach($colrow as $key => $value){
		if($value == 'idRow'){
			break ;
		}
		$a[$count] = $value ;
		#$data = "(CONVERT(`$data` USING utf8) LIKE '%test%'" . $a[$count] ;
		$data = $data . "CONVERT(`$a[$count]` USING utf8) LIKE '%$search%' OR " ;
		$count++ ;
	}
	
}
if($box == "sent"){
$data2 = "SELECT LEFT(message,100),title,msID,time,userSendID,sentID FROM `$DBname` .`$tablename` WHERE " ;	
$sqlinsert=substr($data,0,-3);
$sqlinsert =  $data2 ."(" . $sqlinsert . ") AND `userSendID`='$userID' AND `userResveID`='$userID'" ;

}
if($box == "inbox"){
#SELECT LEFT(message,100),title,msID,time,userSendID
$data2 = "SELECT LEFT(message,100),title,msID,time,userSendID FROM `$DBname` .`$tablename` WHERE " ;
$sqlinsert=substr($data,0,-3);	
$sqlinsert =  $data2 ."(" . $sqlinsert . ") AND `userResveID`='$userID' AND `userSendID` !='$userID'" ;

}
#$sqlinsert=substr($data,0,-3);
#$sqlinsert = $data ;

#$sqlinsert =  $data2 ."(" . $sqlinsert . ") AND `userSendID`='$userID' AND `userResveID`='$userID'" ;
#echo $sqlinsert ;
$searchq = mysqli_query($conn,$sqlinsert) ;

?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				
                    <h1 class="page-header">Search</h1>
					
                </div>
							
                <!-- /.col-lg-12 -->
				<ul class="nav nav-tabs">
							<li><a href="send.php" >Messages System</a>
							
                                </li>
								<?php if($box == "inbox"){
								echo '<li class ="active"><a href="inbox.php" >Inbox</a>
                                </li>' ;
								echo '<li><a href="sent-inbox.php" >Sent Box</a>
                                </li>' ;
							}
							if($box == "sent"){
								echo '<li><a href="inbox.php" >Inbox</a>
                                </li>' ;
								echo '<li class="active"><a href="sent-inbox.php" >Sent Box</a>
                                </li>' ;
							}
							?>
							
								
							<?php if($userID == $groupID){ ?>
                                        <li><a href="broadcast.php">Broadcast Manage</a>
                                        </li>
										<?php } ?>
                                
                            </ul>
							
<form action="m-search.php?box=<?php echo $box ; ?>" method="POST" enctype="multipart/form-data"">
				
										
                                        
                                            <div class="input-group custom-search-form">
                                            <input class="form-control" name="search" placeholder="Search...">
											
                                            <span class="input-group-btn"><button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button></span>
								</div>
                                        </form>
 <!-- /.panel-heading -->
                    <?php if($box == "sent"){ ?>   
                
                          
							
								<form action="ms-delete-all.php" method="POST">
								<?php
								$confvalue="return confirm('You Want to delete this messages?');";
								$confrm = 'onclick='.'"'.$confvalue.'"' ;
								?>
								<div><input type="submit" class="btn btn-danger" style="float:right;" value="Delete selected messages" name="sendg" <?php echo $confrm;?>></div>
								
								 
								 
								</div>
								
                                <table class="table">
                                    <thead>
									
                                        <tr>
											<th>Title</th>
                                            <th>To</th>
											<th>Time</th>
                                            
											<th>Delete</th>
                                            <th>select</th>
											
									 <?php
									   
									  
										 
									
									   while($row = mysqli_fetch_row($searchq)){
										
									   echo '<tr>' ;
									   echo '<td><a href="view-sent.php?msID=',$row[2],'"><b>',$row[1],':',$row[0],'</b></a></td>' ;
									   if($row[5]){
									   $userid = $row[5];
									   $userv = mysqli_query($conn,"SELECT userName FROM `users` WHERE userId='$userid'");
									   $count = mysqli_num_rows($userv);
									   if($count != 0){
										   
									   $userv = mysqli_fetch_row($userv);
									   $userv = $userv[0] ;
									   echo '<td>',$userv,'</td> ';
									   }
									   else{
										  
										$userv = "deleted user" ;
										echo '<td>',$userv,'</td> ';
									   }
									   
									   }
									   echo '<td>',$row[3],'</td>';
									   
									  
									  
									   
									   
										   $icon = '<i class="fa fa-user fa-fw"></i>' ;
										   $icon2 = '<i class="fa fa-trash-o"></i>' ;
										  $titlec = $row[1] ;
											$confvalue="return confirm('You Want to delete this message:$titlec');";
											$confrm = 'onclick='.'"'.$confvalue.'"' ;
										   
										   echo "<td><a  href=\"ms-delete.php?msID=$row[2]\" $confrm>$icon2</td>" ;
										  echo '<td><label><input type="checkbox" name="select[]"  value="',$row[2],'" > </label></td> ' ;
										   
										   
									   echo '</tr>' ;
									   }
									 
									   ?>
									   </form>
                                    </tbody>
                                </table>
								
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>

					<?php }
					if($box == "inbox"){ ?>
 <div class="panel-body">
                            <div class="table-responsive">
								
								<form action="ms-delete-all.php" method="POST">
								<?php
								$confvalue="return confirm('You Want to delete this messages?');";
								$confrm = 'onclick='.'"'.$confvalue.'"' ;
								?>
								<input type="submit" class="btn btn-danger" style="float:right;" value="Delete selected messages" name="sendg" <?php echo $confrm; ?>>
								
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>Title</th>
                                            <th>From</th>
											<th>Time</th>
                                            
											<th>Delete</th>
                                            <th>select</th>
											
									 <?php
									  
									  # $view = mysqli_query($conn,$qms);
									  
										 
									   
									   while($row = mysqli_fetch_row($searchq)){
										
									   echo '<tr>' ;
									   echo '<td><a href="view-ms.php?msID=',$row[2],'"><b>',$row[1],':',$row[0],'</b></a></td>' ;
									   if($row[4]){
									   $userid = $row[4];
									   $userv = mysqli_query($conn,"SELECT userName FROM `users` WHERE userId='$userid'");
									   $count = mysqli_num_rows($userv) ;
									   if($count != 0){
									   $userv = mysqli_fetch_row($userv);
									   echo '<td>',$userv[0],'</td> ';
									   }
									   else{
										   echo '<td>deleted user</td> ';
									   }
									   }
									   echo '<td>',$row[3],'</td>';
									   
									  
									  
									     $titlec = $row[1] ;
											$confvalue="return confirm('You Want to delete this message:$titlec');";
											
											$confrm = 'onclick='.'"'.$confvalue.'"' ;
										   $icon = '<i class="fa fa-user fa-fw"></i>' ;
										   $icon2 = '<i class="fa fa-trash-o"></i>' ;
										  
											
										   
										   echo "<td><a  href=\"ms-delete.php?msID=$row[2]\" $confrm>$icon2</td>" ;
										  echo '<td><label><input type="checkbox" name="select[]"  value="',$row[2],'" > </label></td> ' ;
										   
										   
									   echo '</tr>' ;
									   }
									 
									   ?>
									   </form>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>


<?php			
}
}
}
include('footer.php');
?>