<?php
include('header.php');
if($userID == '1'){
if(isset($_GET['userID'])){
$userid = $_GET['userID'] ;
$checkuser = mysqli_query($conn,"SELECT groupID FROM `users` WHERE userId='$userid'");
$checkuser = mysqli_fetch_row($checkuser) ;
if($userid == '1'){
				$errTyp = "danger";
				$errMSG = "Can't Delete Admin user ";	
}
else if($userid == $checkuser[0]){
	$errTyp = "danger";
	$errMSG = "Can't Delete group admin , please change the group admin and try again  ";
}

	?>
	<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				
                    <h1 class="page-header">Delete user </h1>
					<?php
					if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
					<?php } else{
						$userd = mysqli_query($conn,"SELECT userName FROM `users` WHERE userId='$userid'");
						$userd = mysqli_fetch_row($userd);
						if(isset($_GET['yes'])){
							$userid = $_GET['userID'] ;
							$checkuser = mysqli_query($conn,"SELECT groupID FROM `users` WHERE userId='$userid'");
							$checkuser = mysqli_fetch_row($checkuser) ;
							if($userid == '1'){
								$errTyp = "danger";
								$errMSG = "Can't Delete Admin user ";
							}
							else if($userid == $checkuser[0]){
								$errTyp = "danger";
								$errMSG = "Can't Delete group admin , please change the group admin and try again  ";
}
							else{
							$deleteuser = mysqli_query($conn,"DELETE FROM `users` WHERE userId='$userid'");
							mysqli_query($conn,"DELETE FROM `message_t` WHERE userResveID='$userid'") ;
							if($deleteuser){
								$errTyp = "success";
								$errMSG = "Successfully Delete user ";
							}
						}
						}


					?>
					<?php
					if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
					<?php } ?>
					<div class="col-lg-8">
					<p><h2> if you delete this user all data of this user will deleted , are you want to delete this user "<?php echo $userd[0] ; ?>" ?</h2></p>
					<a href="<?php echo "home.php" ;?>" class="btn btn-warning">No</a>
					<a href="<?php echo "delete-user.php?userID=$userid&yes" ;?>" class="btn btn-info">Yes</a>
					</div>


<?php } ?>



<?php
}
}

else{
	echo "Not allow" ;
}
include('footer.php') ;

?>