<?php
include("../header.php") ;
if($userID == $groupID){
?>

 
 
<?php
#include('include/config.in.php');
//---------------------------------------------------------------------------------------------------
if(isset($_POST['upload'])){
//test extension
$filex = pathinfo($_FILES['file']['name']);	
$extension = $filex['extension'];
$file2 = $_FILES['file']['name'] ;
if($extension == 'xlsx'){
    include ('simplexlsx.class.php');
	
    $xlsx = new SimpleXLSX($file2);
    $fp = fopen( 'tmp.csv', 'w');
    foreach( $xlsx->rows() as $fieldsx ) {
        fputcsv( $fp, $fieldsx);
    }
    fclose($fp);	
	$file = file_get_contents('tmp.csv');
	file_put_contents($file);
	$file = 'tmp.csv' ;
}

else{
	
$file = file_get_contents($_FILES['file']['tmp_name']);
file_put_contents($_FILES['file']['tmp_name'], $file);
$file = $_FILES['file']['tmp_name'];
}
#file_put_contents($_FILES['file']['tmp_name'], $file);
 


$tablename = $_POST['tablename'];
if(empty($_POST['tablename'])){
	#echo "<h2>you must enter table name</h2>" ;
	$filed = 'tmp.csv' ;
	unlink($filed);
	echo "<script>alert('you must enter table name');</script>" ;
	echo "<meta http-equiv=\"refresh\" content=\"0; url=../create-table.php\" />";
}


else{	
$check = mysqli_query($conn,"SELECT tablename FROM `table_n` WHERE tablename='$tablename' AND groupID='$groupID'") ;
$check_count = mysqli_num_rows($check) ;
if($check_count!=0){
	#echo "<h2>Can't create table change the name </h2>" ;
	$filed = 'tmp.csv' ;
	unlink($filed);
	echo "<script>alert('Can not create table change the name'); </script>" ;
	echo "<meta http-equiv=\"refresh\" content=\"0; url=../create-table.php\" />";


}
else {
// get structure from csv and insert db
ini_set('auto_detect_line_endings',TRUE);
$handle = fopen($file,'r');
// first row, structure
if ( ($data = fgetcsv($handle) ) === FALSE ) {
	$filed = 'tmp.csv' ;
	unlink($filed);
    echo "<script>alert('Cannot read from csv $file');</script>";
	echo "<meta http-equiv=\"refresh\" content=\"0; url=../create-table.php\" />";
	die();
	
}

$fields = array();
print_r($fields);
$field_count = 0;
for($i=0;$i<count($data); $i++) {
    $f = strtolower(trim($data[$i]));
    if ($f) {
        // normalize the field name, strip to 20 chars if too long
        #$f = substr(preg_replace ('/[^0-9a-z]/', '_', $f), 0, 20);
        $field_count++;
        #$fields[] = "`$f`".' VARCHAR(255)';
		$fields[] = "`$f`".' TEXT';
    }
}


/* CREATE TABLE IF NOT EXISTS `Table` (
  `idRow` int(7) NOT NULL AUTO_INCREMENT,
  `name1` varchar(50) DEFAULT NULL,
  `email2` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idRow`)
) ENGINE=MYISAM  DEFAULT CHARSET=utf8 ;
 */

$FieldsToAdd=implode(',', $fields);


$table_name="INSERT INTO table_n  VALUES ('$tablename','$groupID')" ;
$Query = mysqli_query($conn,"$table_name");
$tablename2 = $tablename . $groupID;
$tablename2 =  base64_encode($tablename2) ;
$SQL1 = "CREATE TABLE IF NOT EXISTS `$tablename2` ($FieldsToAdd) ENGINE=MYISAM  DEFAULT CHARSET=utf8"; //ENGINE=MYISAM  DEFAULT CHARSET=utf8 for Arabic Support
echo $SQL1 ;
$Query=mysqli_query($conn,"$SQL1");

$SQL2 ="ALTER TABLE `$tablename2` ADD idRow INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST ;" ;
$Query=mysqli_query($conn,"$SQL2");

//insert time to the database
#$SQL3="INSERT INTO timerow (tablename,Time,groupID) VALUES ('$table',CURRENT_TIME(),'$goupID')";
#mysqli_query($conn,"$SQL3");

while ( ($data = fgetcsv($handle) ) !== FALSE ) {
    $fields = array();
    for($i=0;$i<$field_count; $i++) {
        $fields[] = '\''.addslashes($data[$i]).'\'';
    }
	$CSVDATA=implode(',',$fields);
	
    $SQL = "insert into `$tablename2` values('',$CSVDATA)";
	$Query=mysqli_query($conn,$SQL) or die(mysqli_error($conn));
	#echo $SQL; 
	
}

fclose($handle);
ini_set('auto_detect_line_endings',FALSE);
#echo $SQL ;
echo "<h2>Please wait<h2> " ;
$filed = 'tmp.csv' ;
unlink($filed);
echo "<meta http-equiv=\"refresh\" content=\"0; url=../home.php\" />";
}
}
}



?>


</body>
</html>
<?php 
}
include('../footer.php');
 ?>