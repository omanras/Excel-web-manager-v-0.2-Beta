<?php
include('header.php');

if(isset($_POST['select'])){
$delete_id = $_POST['select'] ;
if(empty($delete_id)){
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";
}
 $id = count($delete_id);
	#echo $id ;
    if (count($id) > 0) {
        foreach ($delete_id as $id_d) {
           $sql    = "DELETE FROM `message_t` WHERE msID='$id_d' AND userResveID='$userID'";
           $deleteq = mysqli_query($conn,$sql);
        }
    }

if ($deleteq) {
				$errTyp = "success";
				$errMSG = "Successfully Delete Messages";
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	 
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Delete Messages</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
<?php
if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			?>

<?php
}
include('footer.php');

?>