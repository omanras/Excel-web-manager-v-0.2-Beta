<?php
include('header.php') ;

if($userID == $groupID){
if(isset($_GET['userID'])){	
$userid = $_GET['userID'] ;

if(isset($_POST['edit'])){
	$userid = $_GET['userID'] ;	
	$username = $_POST['username'] ;
	$email = $_POST['email'] ;
	$password = $_POST['password'] ;
	$password2 = $_POST['password2'] ;
	$userq ="SELECT userName,userEmail FROM `users` WHERE userId='$userid'" ;
	$userq = mysqli_query($conn,$userq) ;
	$userq = mysqli_fetch_row($userq) ;
	$email2 = $userq[1] ;
	 
	$username2 = $userq[0]; 	
	if($username2 != $_POST['username']){
	if (empty($username)) {
			$error = true;
			$nameError = "Please enter your full name.";
		} else if (strlen($username) < 3) {
			$error = true;
			$nameError = "Name must have atleat 3 characters.";
		#} else if (!preg_match("/^[a-zA-Z ]+$/",$username)) {
		#	$error = true;
		#	$nameError = "Name must contain alphabets and space.";
		}

			else{
			// check username exist or not
			$query = "SELECT userName FROM users WHERE userName='$username'";
			$result = mysqli_query($conn,$query);
			$count = mysqli_num_rows($result);
			if($count!=0){
				$error = true;
				$nameError = "Provided username is already in use.";
			}
			}
	}
//basic email validation
		if ($email2 != $email){
		if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
			$error = true;
			$emailError = "Please enter valid email address.";
		} else {
			// check email exist or not
			$query = "SELECT userEmail FROM users WHERE userEmail='$email'";
			$result = mysqli_query($conn,$query);
			$count = mysqli_num_rows($result);
			if($count!=0){
				$error = true;
				$emailError = "Provided Email is already in use.";
			}
		}
		}		// password validation
		if (empty($password)){
			$error = true;
			$passError = "Please enter password.";
		} else if(strlen($password) < 6) {
			$error = true;
			$passError = "Password must have atleast 6 characters.";
		}
		else if($password != $password2 ){
			
			$error = true ;
			$passError = "Password not match.";
		
		
		}
		// password encrypt using SHA256();
		$password = hash('sha256', $password);
		// if there's no error, continue to signup
		if( !$error ) {
			
			$query = "UPDATE users SET userName='$username',userEmail='$email',userPass='$password' WHERE userId='$userid' AND groupID='$groupID'";
			
			$res = mysqli_query($conn,$query);
				
			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully update informations";
				unset($username);
				unset($email);
				unset($password);
				unset($password2);
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
				
		}
		
		
	}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Group Settings</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
                 <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
						
						
				 <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">user informations</h3>
                    </div>
					            <?php
			if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			$userq = "SELECT userName,userEmail FROM `users` WHERE userId='$userid' AND groupID='$groupID'" ;
			$userq = mysqli_query($conn,$userq) ;
			$rowu = mysqli_fetch_row($userq);
			?>					
				<div class="panel-body">
                        <form method="POST" action="<?php echo "edit-user2.php?userID=$userid";?>" autocomplete="off">
                            <fieldset>
							<div class="form-group">
                                    <input class="form-control" placeholder="username" name="username" type="input" value="<?php echo "$rowu[0]" ; ?>" autofocus>
									<span class="text-danger"><?php echo $nameError; ?></span>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" value="<?php echo "$rowu[1]" ; ?>" autofocus>
									<span class="text-danger"><?php echo $emailError; ?></span>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" >
									<span class="text-danger"><?php echo $passError; ?></span>
                                </div>
								<div class="form-group">
                                    <input class="form-control" placeholder="conform password" name="password2" type="password" >
									
                                </div>
                                
                                <!-- Change this to a button or input when using this as a form -->
								<input type="submit" class="btn btn-lg btn-success btn-block" name="edit" value="Send">
                                
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
									</div>
		



<?php
}
}
else{
	echo "Not allow";
}
include('footer.php') ;
?>