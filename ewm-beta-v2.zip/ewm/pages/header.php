<?php

ob_start();
session_start();
include('head.php') ;
// if session is not set this will redirect to login page
	
	if( !isset($_SESSION['user']) ) {
		header("Location: login.php");
		exit;
	}
// select loggedin users detail
	$res=mysqli_query($conn,"SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysqli_fetch_array($res);
	$groupID = $userRow['groupID'] ;
	$userID = $userRow['userId'] ;
	$username = $userRow['userName'] ; 
	$groupName = $userRow['groupName'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
<!--
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
-->
    <title>Excel Web Manager v 0.2 Beta</title>
	<!-- table cell CSS -->
	<link href="../js/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">Excel Web Manager v 0.2 Beta</a>
            </div>
            <!-- /.navbar-header -->
			         <ul class="nav navbar-top-links navbar-right">
					 
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="send.php">
                        <i class="fa fa-envelope fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
					
                        <li>
                            <a class="text-center" href="send.php">
                                <strong>Messages System</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
						
						<?php
						#SELECT LEFT(MY_COLUMN, 40) FROM MY_TABLE
						$qms = "SELECT LEFT(message,100),title,msID,time,userSendID FROM `message_t` WHERE userResveID='$userID' AND userSendID !='$userID'" ;
						$viewms = mysqli_query($conn,$qms);
						
						while($rowms = mysqli_fetch_row($viewms)){
						echo '<li class="divider"></li><li>' ;	
						echo '<a href="view-ms.php?msID=',$rowms[2],'">' ;
						echo '<div>';
						echo '<strong>',$rowms[1],'</strong>';
						echo '<span class="pull-right text-muted">' ;
						echo '<em>',$rowms[3],'</em>';
						echo '</span></div>';
						echo '<div>',$rowms[0],'</div>';
						echo '</a>';
						echo '</li>' ;
						}
						?>
                          
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="inbox.php">
                                <strong>Read All Messages</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                
                    <!-- /.dropdown-tasks -->
                </li>
                <!-- /.dropdown -->
                
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="my-setting.php"><i class="fa fa-user fa-fw"></i><?php echo $username; ?></a>
                        </li>
						
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php?logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        
                        <li>
						<?php if($userID == $groupID) { ?>
                            <a href="#"><i class="fa fa-gears fa-fw"></i> Groups Mange<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <?php if($userID == '1') { ?>
								<li>
                                    <a href="create-group.php">Create Group</a>
                                </li>
								<li>
                                    <a href="groups.php">Groups Settings</a>
                                </li>
								<?php } ?>
                                <li>
                                    <a href="group.php">Group Setting</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
						
                        <li>
						<a href="#"><i class="fa fa-table fa-fw"></i> Tables<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                           <li> <a href="tables.php"></i> Tables Settings</a> </li>
							<li> <a href="create-table.php"> Create Table </a></li>
                        </li>
						</ul>
						<?php } ?>
                        
                        
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
		  
