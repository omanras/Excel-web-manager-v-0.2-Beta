<?php
include('header.php');
if($userID == '1'){
if(isset($_GET['groupID'])){
$groupid = $_GET['groupID'] ;
if($groupid == '1'){
	$errTyp = "danger";
	$errMSG = "Can't delete admin group.  ";
}	
else{
	if(isset($_GET['yes'])){
		$groupid = $_GET['groupID'];
	if($groupid == '1'){
	$errTyp = "danger";
	$errMSG = "Can't delete admin group.  ";
}	
else{
	$delete = mysqli_query($conn,"SELECT tablename FROM `table_n` WHERE groupID='$groupid'");
	while($deleterow = mysqli_fetch_row($delete)){
		$tablename = $deleterow[0] . $groupid ;
		$tablename2 = base64_encode($tablename);
		mysqli_query($conn,"DROP TABLE `$tablename2`") ;
	}
	mysqli_query($conn,"DELETE FROM `table_n` WHERE groupID='$groupid'") ;
	mysqli_query($conn,"DELETE FROM `users` WHERE groupID='$groupid'") ;
	mysqli_query($conn,"DELETE FROM `message_t` WHERE userGroupID='$groupid'");
	mysqli_query($conn,"DELETE FROM `broadcast_t` WHERE userSendID='$groupid'");
	
}
if($delete){
	$errTyp = "success" ;
	$errMSG = "Successfully delete group." ;
}
	}
}
?>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				<?php 
				$groupname = mysqli_query($conn,"SELECT groupName FROM `users` WHERE groupID='$groupid'");
				$groupname = mysqli_fetch_row($groupname);
				?>
                    <h1 class="page-header">Delete group  : <?php echo $groupname[0] ; ?> </h1>
						<?php
					if ( isset($errMSG) ) {
				
				?>
<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
					<?php } ?>
					<div class="col-lg-8">
					<p><h2> if you delete this group all data of this group will deleted , are you want to delete this group "<?php echo $groupname[0] ; ?>" ?</h2></p>
					<a href="<?php echo "home.php" ;?>" class="btn btn-warning">No</a>
					<a href="<?php echo "delete-group.php?groupID=$groupid&yes" ;?>" class="btn btn-info">Yes</a>
					</div>

<?php
}
}
include('footer.php');
?>