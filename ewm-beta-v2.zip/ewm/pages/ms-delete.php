<?php
include('header.php');

if(isset($_GET['msID'])){
	$msID = $_GET['msID'];
	$deleteq = mysqli_query($conn,"DELETE FROM `message_t` WHERE msID='$msID' AND userResveID='$userID'") ;
	if ($deleteq) {
				$errTyp = "success";
				$errMSG = "Successfully Delete Messages";
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	


?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Delete Messages</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
<?php
if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			?>
<?php
}
include('footer.php') ;

?>