<?php
include('header.php');
if($userID == $groupID){
?>
<?php
if(isset($_POST['create'])){
	$tablename = $_POST['tablename'];
	$groupID = $groupID ;
	$col = $_POST['columns'];
	$tablename2 = $tablename.$groupID ;
	$tablename2 = base64_encode($tablename2) ;

	
	if(empty($tablename)){
		$error = true ;
		$errormsg = "Please Enter table name. " ;
	}
	elseif(empty($col)){
		$error = true ;
		$errormsgcol = "Please Enter Columns. " ;
	}
	else{
		$checktable = mysqli_query($conn,"SELECT tablename FROM `table_n` WHERE tablename='$tablename' AND groupID='$groupID'");
		
		$checktablec = mysqli_num_rows($checktable);
		
		if($checktablec !=0){
			$error = true ;
			$errormsg= "The table name is already in use." ;
		}
		else{
	
	mysqli_query($conn,"INSERT INTO table_n VALUES ('$tablename','$groupID')");
	$col = '`' . $col . '`' ;
	$col2 = str_replace(",","` TEXT,`",$col)  ;
	$col2  = $col2 . " TEXT" ;
	#echo $col2 ;
	mysqli_query($conn,"CREATE TABLE IF NOT EXISTS `$tablename2` ($col2) ENGINE=MYISAM  DEFAULT CHARSET=utf8");
	$SQL2 ="ALTER TABLE `$tablename2` ADD idRow INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST ;" ;
	$Query=mysqli_query($conn,$SQL2);
	if($Query){
		$errTyp = "success";
		$errMSG = "Successfully Create table.";
	}
	else {
		$errTyp = "danger";
	    $errMSG = "Something went wrong, try again later...";
	}
	
		}
	}
	
	
	
}


?>


<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Create Table</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

					
					<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                                               		            <?php
			if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			} ?>
							<form action="create-table.php" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
										<label>Create table in simple steps </label>
										<br>
										<span class="text-danger"><?php echo $errormsg; ?></span>
                                            <label>Enter Table Name :</label>
											<span class="text-danger"></span>
											 <input class="form-control"  name="tablename" >
											<span class="text-danger"><?php echo $errormsgcol; ?></span>
											 <label>Enter columns names :</label>
											<input class="form-control"  name="columns" placeholder="Example : column1,column2,col3...." >
                                            <br>
											<input type="submit" class="btn btn-primary" name="create" value="Create">
										
                                        </div>
                        
						</form>
						
						<br>
							<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                                               		            
							<form action="simplexlsx-master/create.php" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
										<label>Create table by upload file </label>
										<br>
										<span class="text-danger"><?php echo $errormsg; ?></span>
                                            <label>Enter Table Name :</label>
											<span class="text-danger"></span>
											 <input class="form-control"  name="tablename" >
											<span class="text-danger"><?php echo $errormsgcol; ?></span>
											 <label>Upload CSV,XLXS file :</label>
											<input type="file" name="file">
                                            <br>
											<input type="submit" class="btn btn-primary" name="upload" value="Upload">
										
                                        </div>
                        </div>
						</form>
						


					
					
<?php
}
else{
	echo "Not allow" ;
}
include('footer.php')
?>