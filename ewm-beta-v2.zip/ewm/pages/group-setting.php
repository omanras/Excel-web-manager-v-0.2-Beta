<?php
include('header.php') ;
if($userID == '1'){
?>

<?php
if(isset($_POST['rename'])){
	$rename = $_POST['rename2'];
	$groupid = $_GET['groupID'] ;
    	if (empty($rename)) {
			$error = true;
			$nameError = "Please enter your full name.";
		} else if (strlen($rename) < 3) {
			$error = true;
			$nameError = "Name must have atleat 3 characters.";
		#} else if (!preg_match("/^[a-zA-Z ]+$/",$rename)) {
		#	$error = true;
		#	$nameError = "Name must contain alphabets and space.";
		}
	else {
			// check username exist or not
			$query = "SELECT groupName FROM `users` WHERE groupName='$rename'";
			$result = mysqli_query($conn,$query);
			$count = mysqli_num_rows($result);
			if($count!=0){
				$error = true;
				$nameError = "Provided group name is already in use.";
			}
		}	
if( !$error ) {
			$groupname = mysqli_query($conn,"SELECT groupName FROM `users` WHERE groupID='$groupid'");
			$groupname = mysqli_fetch_row($groupname) ;
			$groupname = $groupname[0] ;
			$query = "UPDATE users SET groupName='$rename' WHERE groupID ='$groupid'";
			mysqli_query($conn,"UPDATE broadcast_t SET groupName='$rename' WHERE groupName='$groupname'");
			$res = mysqli_query($conn,$query);
				
			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully rename";
				unset($rename);
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
				
		}
		
		}
?>







<?php
if(isset($_GET['groupID'])){
	$groupid = $_GET['groupID'] ;
	#$viwe = mysqli_query($conn,"SELECT userId,userName From `users` WHERE groupID=$groupid");
}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Groups Settings</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
					            <?php
			if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			?>
			 <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           
							<form action="<?php echo "group-setting.php?groupID=$groupid" ; ?> " method="POST">
                                        <div class="form-group">
										
                                            <label>Rename Group</label>
											<span class="text-danger"><?php echo $nameError; ?></span>
											<?php $q = mysqli_query($conn,"SELECT groupName FROM `users` WHERE groupID='$groupid'");
											$q = mysqli_fetch_row($q) ;
											?>
                                            <input class="form-control" value="<?php echo $q[0] ; ?>" name="rename2" >
                                            <br>
											<input type="submit" class="btn btn-primary" name="rename" value="Rename">
										
                                        </div>
                        </div>
						</form>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
								
								<a href="<?php echo "add-user.php?groupID=$groupid" ;?>" class="btn btn-info">Add user</a>
								 <?php if($groupid != '1'){ ?>
								 <a href="<?php echo "change-admin.php?groupID=$groupid" ;?>" class="btn btn-warning">Change group admin</a>
								 <a href="<?php echo "delete-group.php?groupID=$groupid" ;?>" class="btn btn-danger" style="float:right;">Delete group </a>
								 <?php } ?>
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>UserID</th>
                                            <th>User Name</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
											  <?php
									   $view = mysqli_query($conn,"SELECT userId,userName FROM `users` WHERE groupID = $groupid") ;
									   
									   while($row = mysqli_fetch_row($view) ){
									   echo '<tr>' ;
									   foreach($row as $key => $value){
										   
										   echo "<td>$value</td>" ;
										   
									   }
									   
									   
										   $icon = '<i class="fa fa-user fa-fw"></i>' ;
										   $icon2 = '<i class="fa fa-trash-o"></i>' ;
										  
											
										   
										   
										    echo "<td><a  href=\"edit-user.php?userID=$row[0]\">$icon</td>" ;
										   echo "<td><a  href=\"delete-user.php?userID=$row[0]\">$icon2</td>" ;
										   
									   echo '</tr>' ;
									   }
									   ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>


<?php
}
else{
	echo "Not allow" ;
}
include('footer.php') ;
?>