<?php
include('header.php');
if($userID == $groupID){
if(isset($_GET['tablename'])){
$tablename = $_GET['tablename'];	
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);

if(isset($_POST['rename'])){
#RENAME TABLE old_table TO new_table;	
$tablename = $_GET['tablename'];
$renametable = $_POST['renametable'] ;	
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);
$tablename3 = $renametable . $groupID ;
$tablename3 = base64_encode($tablename3);
if(empty($renametable)){
	$errTyp2 = "danger" ;
	$errMSG = "please enter table name  ." ;
	$errormsgtablename = "please enter table name  ." ;
}
else{
$checktable = mysqli_query($conn,"SELECT tablename FROM `table_n` WHERE tablename='$renametable' AND groupID='$groupID'");
$checktablec = mysqli_num_rows($checktable);
		
		if($checktablec !=0){
			
			$errTyp2 = "danger" ;
			$errMSG = "The table name is already in use." ;
			$errormsgtablename = "The table name is already in use." ;
		}	
else{		
$rename = mysqli_query($conn,"RENAME TABLE `$tablename2` TO `$tablename3`");
mysqli_query($conn,"UPDATE table_n SET tablename ='$renametable' WHERE tablename='$tablename' AND groupID = '$groupID'");
$errTyp2 = "success" ;
$errMSG = "Successfully update information" ;
}
}
}
if(isset($_POST['renamecol'])){
#RENAME column | ALTER TABLE `dgvzdcb0ywjszte=` CHANGE `note` `notex` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;	
$tablename = $_GET['tablename'];
$colname = $_POST['colname'];
$colselect = $_POST['colselect'];	
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);
if($colselect == 'Disabled select'){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgrenamecol = "please select column ." ;
	
}	
else if(empty($colselect)){
	$errTyp = 'danger';	
	$errMSG = "please select column ."  ;
	$errormsgrenamecol = "please select column ." ;
}
else if(empty($colname)){
	$errTyp = 'danger';	
	$errMSG = "please enter column name  ." ;
	$errormsgrenamecol = "please enter column name  ." ;
}
else if($colname){
	$check = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'");
	while($checkcol = mysqli_fetch_row($check)){
	if($checkcol[0] == $colname){
	$errTyp = 'danger';	
	$errMSG = "column name is already in use  ." ;
	$errormsgrenamecol = "column name is already in use  ." ;
	break ;
	}
	else{
	$renamecol = mysqli_query($conn,"ALTER TABLE `$tablename2` CHANGE `$colselect` `$colname` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL");
	$errTyp = "success" ;
	$errMSG = "Successfully update information" ;
 }
	}
} 

}

if(isset($_POST['add'])){
#ADD column Befor/After  | ALTER TABLE `users` ADD `ss` INT NOT NULL AFTER `userPass`	
$tablename = $_GET['tablename'];
$colname = $_POST['colname'];	
$colselect = $_POST['colselect'];	
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);
if($colselect == 'Disabled select'){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgaddcol = "please select column ." ;
	
}	
else if(empty($colselect)){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgaddcol = "please select column ." ;
}	
else if(empty($colname)){
	$errTyp = "danger";
	$errMSG = "please enter column name  ." ;
	$errormsgaddcol = "please enter column name  ." ;
}
else if($colname){
	$check = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'");
	while($checkcol = mysqli_fetch_row($check)){
	if($checkcol[0] == $colname){
	$errTyp = "danger";
	$errMSG = "column name is already in use  ." ;
	$errormsgaddcol = "column name is already in use  ." ;
	break ;
	}
	else{
	if($colselect == 'First'){
		
	$addcol = mysqli_query($conn,"ALTER TABLE `$tablename2` ADD `$colname` TEXT NOT NULL AFTER `idRow`") ;
	$errTyp = "success" ;
	$errMSG = "Successfully update information" ;
			
	}	
	else{
	$addcol = mysqli_query($conn,"ALTER TABLE `$tablename2` ADD `$colname` TEXT NOT NULL AFTER `$colselect`");
	$errTyp = "success" ;
	$errMSG = "Successfully update information" ;
	}
	}
	}
} 
}

if(isset($_POST['replace'])){
#ALTER TABLE `table_name` MODIFY `column_you_want_to_move` DATATYPE AFTER `column`	
$tablename = $_GET['tablename'];
$colselect = $_POST['colselect'];	
$colselect2 = $_POST['colselect2'];
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);	
if($colselect2 == 'Disabled select'){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgreplacecol = "please select column ." ;
	
}	
else if($colselect == 'Disabled select'){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgreplacecol = "please select column ." ;
	
}	
else if(empty($colselect)){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgreplacecol = "please select column ." ;
}
else if(empty($colselect2)){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgreplacecol = "please select column ." ;
}
else{
	$replace = mysqli_query($conn,"ALTER TABLE `$tablename2` MODIFY `$colselect` TEXT AFTER `$colselect2`") ;
	$errTyp = "success" ;
	$errMSG = "Successfully update information" ;
}	
}
if(isset($_POST['delete'])){
#Delete column | "ALTER TABLE `pentest` DROP `company_name`";
$tablename = $_GET['tablename'];
$colselect = $_POST['colselect'];	
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);	
if($colselect == 'Disabled select'){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgdeletecol = "please select column ." ;
	
}
else if(empty($colselect)){
	$errTyp = 'danger';
	$errMSG = "please select column ." ;
	$errormsgdeletecol = "please select column ." ;
}
else{
	$deletecol = mysqli_query($conn,"ALTER TABLE `$tablename2` DROP `$colselect`");
	$errTyp = "success" ;
	$errMSG = "Successfully update information" ;
}	
}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Table Settings of <?php echo $tablename; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
					<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
								            <?php
			if ( isset($errTyp2) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp2=="success") ? "success" : $errTyp2; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			} ?>
						<form action="table-setting.php?tablename=<?php echo $tablename;?>" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
										<label>Rename table </label>
										<br>
										<span class="text-danger"><?php echo $errormsgtablename; ?></span>
                                            
											<span class="text-danger"></span>
											 <input class="form-control"  name="renametable" value="<?php echo $tablename ; ?>" >
											 <br>
											 <input type="submit" class="btn btn-primary" name="rename" value="Rename">

						
						 </form>
						 
						 <div>
						<strong>Insert data to table by upload file</strong>
                        
                        
                            <form action="simplexlsx-master/table-up.php?tablename=<?php echo $tablename; ?>" method="POST" enctype="multipart/form-data">
							<label>Upload CSV,XLXS file :</label>
							<input type="file" name="file">
                             <br>
							<input type="submit" class="btn btn-primary" name="upload" value="Upload">
							
							</form></div>
											
											 
											 </div>
											 </div>
											 </div>
											 
											
											 
											 
											 
											 
				<div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
						  <?php
			if ( isset($errTyp) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			} ?>
                          <strong>  Columns </strong>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						 <div class="list-group">
						 <form action="table-setting.php?tablename=<?php echo $tablename;?>" method="POST" enctype="multipart/form-data">
											 <label>Rename column :</label>
											 <span class="text-danger"><?php echo $errormsgrenamecol; ?></span>
											<input class="form-control" name="colname">
											<label>Select column : </label>
											<span class="text-danger"></span>
											<div>
                                                <select id="disabledSelect" class="form-control" name="colselect">
												<option>Disabled select</option>
												
											<?php 
											$result = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'") or die('cannot show tables');
											while($colrow = mysqli_fetch_row($result)){
												foreach($colrow as $key => $value){
													if($value == 'idRow'){
														break ;
													}
												echo '<option value="',$value,'">',$value,'</option> ';
												}
											}
											?>
											
												                                                   
                                                </select>
												
                                            </div>

                                            <br>
											<input type="submit" class="btn btn-primary" name="renamecol" value="Rename column">
										</form>
                                        
										<br>
											
											<form action="table-setting.php?tablename=<?php echo $tablename;?>" method="POST" enctype="multipart/form-data">
											 <label>Column Name :</label>
											 <span class="text-danger"><?php echo $errormsgaddcol; ?></span>
											<input class="form-control" name="colname">
											<label>After : </label>
											<span class="text-danger"></span>
											<div>
                                                <select id="disabledSelect" class="form-control" name="colselect">
												<option>Disabled select</option>
												<option value="First">First</option>
											<?php 
											$result = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'") or die('cannot show tables');
											while($colrow = mysqli_fetch_row($result)){
												foreach($colrow as $key => $value){
													if($value == 'idRow'){
														break ;
													}
												echo '<option value="',$value,'">',$value,'</option> ';
												}
											}
											?>
											
												                                                   
                                                </select>
												
                                            </div>

                                            <br>
											<input type="submit" class="btn btn-info" name="add" value="Add column">
										</form>
                                        
										</div>
					
                             
                        
                        <!-- /.panel-heading -->
						
                        
										<form action="table-setting.php?tablename=<?php echo $tablename;?>" method="POST" enctype="multipart/form-data">
										
										<label>Replace column  :</label>
										<span class="text-danger"><?php echo $errormsgreplacecol; ?></span>
										<div>
                                                <select id="disabledSelect" class="form-control" name="colselect">
												<option>Disabled select</option>
												
                        <?php 
											$result = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'") or die('cannot show tables');
											while($colrow = mysqli_fetch_row($result)){
												
												foreach($colrow as $key => $value){
													if($value == 'idRow'){
														break ;
													}
												echo '<option value="',$value,'">',$value,'</option> ';
												}
											}
											?>
											
												                                                   
                                                </select>
                                            </div>
														
										<label>After column  :</label>
										<div>
                                                <select id="disabledSelect" class="form-control" name="colselect2">
												<option>Disabled select</option>
                        <?php 
											$result = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'") or die('cannot show tables');
											while($colrow = mysqli_fetch_row($result)){
												foreach($colrow as $key => $value){
													if($value == 'idRow'){
														break ;
													}
												echo '<option value="',$value,'">',$value,'</option> ';
												}
											}
											?>
											
												                                                   
                                                </select>
												<br>
												<input type="submit" class="btn btn-primary" name="replace" value="Replace">
						</form>
										</div>
										<br>	
										<label>Delete column  :</label>
										<span class="text-danger"><?php echo $errormsgdeletecol; ?></span>
										<div>
										<form action="table-setting.php?tablename=<?php echo $tablename;?>" method="POST" enctype="multipart/form-data">
                                                <select id="disabledSelect" class="form-control" name="colselect">
												<option>Disabled select</option>
                        <?php 
											$result = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'") or die('cannot show tables');
											while($colrow = mysqli_fetch_row($result)){
												foreach($colrow as $key => $value){
													if($value == 'idRow'){
														break ;
													}
												echo '<option value="',$value,'">',$value,'</option> ';
												}
											}
											?>
											
												                                                   
                                                </select>
												<br>
												<?php
												$confvalue="return confirm('If you delete this column all data will be deleted ?');";
												$confrm = 'onclick='.'"'.$confvalue.'"' ;
												?>
												<input type="submit" class="btn btn-danger" name="delete" value="Delete" <?php echo $confrm; ?>>
												</form>
												
												
						
            </div>
			</div>
			</div>
			 
			
			

<?php
}
}
include('footer.php');
?>