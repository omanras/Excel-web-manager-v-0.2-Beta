<?php
include('header.php');
if($userID == $groupID){
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Broadcast Manage</h1>
                </div>
                <!-- /.col-lg-12 -->
				<ul class="nav nav-tabs">
							<li><a href="send.php" >Messages System</a>
                                </li>
								<li><a href="inbox.php" >Inbox</a>
                                </li>
							<li><a href="sent-inbox.php" >Sent Box</a>
                                </li>
							<?php if($userID == $groupID){ ?>
                                        <li class="active"><a href="broadcast.php">Broadcast Manage</a>
                                        </li>
										<?php } ?>
                                
                            </ul>
							</div>

 <!-- /.panel-heading -->
 
                        <div class="panel-body">
                            <div class="table-responsive">
								
								<form action="broadcast-delete.php?all" method="POST">
								<?php
								$confvalue="return confirm('You Want to delete this broadcasts?');";
								$confrm = 'onclick='.'"'.$confvalue.'"' ;
								?>
								<input type="submit" class="btn btn-danger" style="float:right;" value="Delete selected broadcasts" name="sendg" <?php echo $confrm; ?>>
								
								
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>Title</th>
                                            <th>To group</th>
											<th>Time</th>
                                            
											<th>Delete</th>
                                            <th>select</th>
											
									 <?php
										
									  
									   $view = mysqli_query($conn,"SELECT brID,LEFT(message,50),title,userSendID,groupName,time FROM `broadcast_t` WHERE userSendID='$userID'");
									  
										 
									   
									   while($row = mysqli_fetch_row($view)){
										
									   echo '<tr>' ;
									   echo '<td><a href="broadcast-view.php?brID=',$row[0],'&userID=',$userID,'"><b>',$row[2],':',$row[1],'</b></a></td>' ;
									  
									   echo '<td>',$row[4],'</td> ';
									   
									   echo '<td>',$row[5],'</td>';
									   
									  
									  
									     $titlec = $row[2] ;
											$confvalue="return confirm('You Want to delete this broadcast:$titlec');";
											
											$confrm = 'onclick='.'"'.$confvalue.'"' ;
										   $icon = '<i class="fa fa-user fa-fw"></i>' ;
										   $icon2 = '<i class="fa fa-trash-o"></i>' ;
										  
											
										   
										   echo "<td><a  href=\"broadcast-delete.php?brID=$row[0]\" $confrm>$icon2</td>" ;
										  echo '<td><label><input type="checkbox" name="select[]"  value="',$row[0],'" > </label></td> ' ;
										   
										   
									   echo '</tr>' ;
									   }
									 
									   ?>
									   </form>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>

<?php
}
include('footer.php');
?>