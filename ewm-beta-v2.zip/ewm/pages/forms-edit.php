<?php
include('header.php');
$tablename = $_GET['tablename'];
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);
$idRow = $_GET['idRow'] ;

if(isset($_POST['update'])){
$tablename = $_GET['tablename'];
$tablename2 = $tablename . $groupID ;
$tablename2 = base64_encode($tablename2);
$idRow = $_GET['idRow'] ;
$row = $_POST ;
foreach($row as $key => $val){
	#key = base64_decode($key) ;
	if($key == 'update'){
		break ;
	}
	$key = base64_decode($key) ;
	$Query = "UPDATE `$tablename2` SET `$key` = '$val' WHERE idRow = '$idRow' ;" ;
	$Query=mysqli_query($conn,$Query) ;
}
	if($Query){
					$errTyp = "success" ;
				$errormsg = "Successfully update informations" ;
				echo "<meta http-equiv=\"refresh\" content=\"3; url=table-view.php?tablename=$tablename\" />";
				}
				else{
				$errTyp = "danger";
				$errormsg = "Error can't update informations ." ;
				}


	}



?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit record in : <?php echo $tablename; ?></h1>
                </div>
				</div>
					<?php 
					if ( isset($errTyp) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errormsg; ?>
                </div>
            	</div>
                <?php
			} ?>
<form action="forms-edit.php?tablename=<?php echo $tablename ; ?>&idRow=<?php echo $idRow;?>" method="POST" enctype="multipart/form-data">
<?php
$form = mysqli_query($conn,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$tablename2'");
$result = mysqli_query($conn,"SELECT * FROM `$tablename2` WHERE idRow='$idRow'") ;
while($row = mysqli_fetch_array($result)){
	while($row2 = mysqli_fetch_row($form)){
		foreach($row2 as $key => $value){
			if($value == 'idRow'){
				break ;
			}
			$value2 = base64_encode($value) ;
			echo '<strong>',$value ,':</strong><input class="form-control" type="text" name="',$value2,'" value="',$row[$value],'"> ';
		}
	}
	
}
?>
<br>
<input type="submit" class="btn btn-primary" name="update" value="update">

</form>
<?php
include('footer.php');
?>