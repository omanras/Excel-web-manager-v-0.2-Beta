<?php
include('header.php');

?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Inbox</h1>
                </div>
                <!-- /.col-lg-12 -->
				                           <ul class="nav nav-tabs">
							<li><a href="send.php" >Messages System</a>
                                </li>
								<li class="active"><a href="inbox.php" >Inbox</a>
                                </li>
							<li><a href="sent-inbox.php" >Sent Box</a>
                                </li>
							<?php if($userID == $groupID){ ?>
                                        <li><a href="broadcast.php">Broadcast Manage</a>
                                        </li>
										<?php } ?>
                                
                            </ul>
							</div>
							<br>
				<form action="m-search.php?box=inbox" method="POST" enctype="multipart/form-data"">
				
										
                                        
                                            <div class="input-group custom-search-form">
                                            <input class="form-control" name="search" placeholder="Search...">
											
                                            <span class="input-group-btn"><button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button></span>
								</div>
                                        </form>
 <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
								
								<form action="ms-delete-all.php" method="POST">
								<?php
								$confvalue="return confirm('You Want to delete this messages?');";
								$confrm = 'onclick='.'"'.$confvalue.'"' ;
								?>
								<input type="submit" class="btn btn-danger" style="float:right;" value="Delete selected messages" name="sendg" <?php echo $confrm; ?>>
								
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>Title</th>
                                            <th>From</th>
											<th>Time</th>
                                            
											<th>Delete</th>
                                            <th>select</th>
											
									 <?php
									  
									   $view = mysqli_query($conn,$qms);
									  
										 
									   
									   while($row = mysqli_fetch_row($view)){
										
									   echo '<tr>' ;
									   echo '<td><a href="view-ms.php?msID=',$row[2],'"><b>',$row[1],':',$row[0],'</b></a></td>' ;
									   if($row[4]){
									   $userid = $row[4];
									   $userv = mysqli_query($conn,"SELECT userName FROM `users` WHERE userId='$userid'");
									   $count = mysqli_num_rows($userv) ;
									   if($count != 0){
									   $userv = mysqli_fetch_row($userv);
									   echo '<td>',$userv[0],'</td> ';
									   }
									   else{
										   echo '<td>deleted user</td> ';
									   }
									   }
									   echo '<td>',$row[3],'</td>';
									   
									  
									  
									     $titlec = $row[1] ;
											$confvalue="return confirm('You Want to delete this message:$titlec');";
											
											$confrm = 'onclick='.'"'.$confvalue.'"' ;
										   $icon = '<i class="fa fa-user fa-fw"></i>' ;
										   $icon2 = '<i class="fa fa-trash-o"></i>' ;
										  
											
										   
										   echo "<td><a  href=\"ms-delete.php?msID=$row[2]\" $confrm>$icon2</td>" ;
										  echo '<td><label><input type="checkbox" name="select[]"  value="',$row[2],'" > </label></td> ' ;
										   
										   
									   echo '</tr>' ;
									   }
									 
									   ?>
									   </form>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>

<?php
include('footer.php');
?>