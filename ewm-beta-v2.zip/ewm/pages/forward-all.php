<?php
include('header.php');
if($userID == $groupID){
	
	
?>
<?php
		if(isset($_GET['send'])){
		$userSendID = $userID ;
		$title = $_POST['title'] ;
		$message = $_POST['message'];
		$groupname = $_POST['groupname'];
		$id = count($groupname) ;
	
		if (count($id) > 0) {
					foreach ($groupname as $id_d) {
					$usercheck = mysqli_query($conn,"SELECT userId,groupID FROM `users` WHERE userId='$id_d'");
					$usercheck = mysqli_fetch_row($usercheck) ;
					$useridc = $usercheck[0] ;
					$groupidc = $usercheck[1] ;
					if($id_d == $groupidc){
					$userGroupID = $id_d ; 
					$groupq = "INSERT INTO `message_t` VALUES ('','$userSendID','$userGroupID','$id_d','','$title','$message',CURRENT_TIME()) " ;
					$groupq2 = "INSERT INTO `message_t` VALUES ('','$userSendID','$groupID','$userID','$id_d','$title','$message',CURRENT_TIME()) " ;
					$groupn = mysqli_query($conn,$groupq) ;
					mysqli_query($conn,$groupq2) ;
					}	
					else{
					if($id_d == $groupID){	
					$userGroupID = $groupID ;
					$groupq = "INSERT INTO `message_t` VALUES ('','$userSendID','$userGroupID','$id_d','','$title','$message',CURRENT_TIME()) " ;
					$groupq2 = "INSERT INTO `message_t` VALUES ('','$userSendID','$groupID','$userID','$id_d','$title','$message',CURRENT_TIME()) " ;
					$groupn = mysqli_query($conn,$groupq) ;
					mysqli_query($conn,$groupq2) ;
					}
					else{
				     $errTyp = "danger";
				     $errMSG = "Can't send this message.";
					}
					}
					
					
						}
				if ($groupn) {
				$errTyp = "success";
				$errMSG = "Successfully message Send";
				
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
		}
		
							          
			if ( isset($errMSG) ) {
				
				?>
				<div id="page-wrapper">
				<div class="row">
                <div class="col-lg-12">
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
				</div>
				</div>
				</div>
                <?php
			}
			
		
	}





if(isset($_POST['sendms'])){
	$msID = $_GET['msID'] ;
	$userSendID = $userID ;
	$userid = $_POST['select'] ;
	$id = count($groupid);
	

?>
<div id="page-wrapper">
         <form action="forward-all.php?msID=<?php echo $msID ;?>&send" method="POST">

            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Forward Message</h1>
					<?php 
					if (count($id) > 0) {
						foreach ($userid as $id_d) {
					$groupq = "SELECT userName,userId From `users` WHERE userId='$id_d' " ;
					
					$groupn = mysqli_query($conn,$groupq) ;
					$groupname = mysqli_fetch_row($groupn) ;	
					#echo '<p name="groupname[]"><b>To : ', $groupname[0],' </b></p>' ;
					echo '<label><input type="checkbox" name="groupname[]"  value="',$groupname[1],'" checked>',$groupname[0], ' </label><br>' ;
					}
					}
					?>
                </div>
                <!-- /.col-lg-12 -->
            </div>

<div class="row">
<?php
$qmsid = mysqli_query($conn,"SELECT title,message FROM `message_t` WHERE msID='$msID' AND userResveID='$userID'");
$rowmsid = mysqli_fetch_row($qmsid) ;
?>
                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Message Title</label>
                                            <input class="form-control" name="title" value="Forward:<?php echo $rowmsid[0] ;?>">
                                            
                                        </div>


<div>
 <label>Message</label>
    <textarea class="form-control" rows="12" name="message">
"<?php echo $rowmsid[1] ; ?>"	
	
	</textarea>


	</div>
	<br>
	<input type="submit" class="btn btn-success" name="send" value="Forward">
	</form>
<?php	
}

?>


<?php
 #$viewpage ;
}
else{
	echo "Not allow" ;
}
include('footer.php');

?>