<?php

include('header.php');
if($userID == '1'){
if(isset($_GET['groupID'])){
	$groupid = $_GET['groupID'];
	if(isset($_POST['change'])){
		$groupid = $_GET['groupID'];
		$select = $_POST['select'];
		if($groupid == '1'){
			$errTyp = "danger";
			$errMSG = "Can't Change admin of this group";
		}
		else{
		$groupq = mysqli_query($conn,"SELECT groupName FROM `users` WHERE groupID='$groupid' AND userId='$groupid'");
		$groupq = mysqli_fetch_row($groupq);
		$groupname = $groupq[0] ;
		mysqli_query($conn,"UPDATE message_t SET userGroupID='$select' WHERE userGroupID='$groupid'");
		#tables change admin 
		$changeq = mysqli_query($conn,"SELECT * FROM `table_n` WHERE groupID='$groupid'");
		
		
		
		while($rowchange = mysqli_fetch_row($changeq)){
			
			#mysqli_query($ConnectDB,"RENAME TABLE `$table` TO `$table2`");
			$tablename = $rowchange[0].$rowchange[1];
			$tablename = base64_encode($tablename);
			$tablename2 = $rowchange[0].$select ;
			$tablename2 = base64_encode($tablename2);
			
			mysqli_query($conn,"RENAME TABLE `$tablename` TO `$tablename2`");
		}
		mysqli_query($conn,"UPDATE table_n SET groupID='$select' WHERE groupID='$groupid'");
		$res = mysqli_query($conn,"UPDATE users SET groupID='$select' WHERE groupName='$groupname'");
		mysqli_query($conn,"UPDATE broadcast_t SET userSendID='$select' WHERE userSendID='$groupid'");
		
				
			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully change group admin ";
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
		}
	}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Groups Settings </h1>
					
                </div>
			<?php	if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}?>
                <!-- /.col-lg-12 -->
            </div>
 <div class="panel-body">
                            <div class="table-responsive">
								
								
								 <p><b>Change the group admin </b></p>
								 <form action="<?php echo "change-admin.php?groupID=$groupid";?>" method="POST">
								 <input type="submit" class="btn btn-primary" name="change" value="Change">
                                <table class="table">
                                    <thead>
                                        <tr>
											<th>UserID</th>
                                            <th>User Name</th>
                                            <th>Select</th>
                                            
											  <?php
									   $view = mysqli_query($conn,"SELECT userId,userName FROM `users` WHERE groupID = $groupid") ;
									   
									   while($row = mysqli_fetch_row($view) ){
									   echo '<tr>' ;
									   foreach($row as $key => $value){
										   echo '<div class="radio"> ' ;
										   echo "<td>$value</td>" ;
										   
									   }
									   
									   
										   
										  
                                        echo '<td><label><input type="radio" name="select"  value="',$row[0],'" checked> </label></td> ' ;
                                               
										    
										
									   
									   echo '</tr>' ;
									   }
									   
									   ?>
									   </div>
                                    </tbody>
                                </table>
								</form>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>


<?php
}
}
else{
	echo "Not allow" ;
}
include('footer.php');
?>