<?php
include('header.php') ;
?>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
				<!-- /.panel-heading -->
		  
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs">
							<li class="active"><a href="home.php" >Home</a>
                                </li>
							<?php
							$table = mysqli_query($conn,"SELECT tablename FROM `table_n` WHERE groupID='$groupID'");
							while($tablerow=mysqli_fetch_row($table)){
								echo '<li><a href="table-view.php?tablename=',$tablerow[0],'" >',$tablerow[0],'</a>' ;
                                echo '</li>' ;
							}
							?>
                                
                            </ul>
							</div>
							</div>
							</div>
							
                            <!-- Tab panes -->
                    <h1 class="page-header">Home</h1>
					<div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="glyphicon glyphicon-bullhorn"></i> Broadcasts
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						 <div class="list-group">
						<?php
						
						$brq = mysqli_query($conn,"SELECT brID,LEFT(message,10),title,userSendID,groupName,time FROM `broadcast_t` WHERE groupName='$groupName'");
						while($rowb = mysqli_fetch_row($brq)){
						$userbid = $rowb[3];	
						$userb = mysqli_query($conn,"SELECT userName FROM `users` WHERE userId='$userbid'");
						$userb = mysqli_fetch_row($userb) ;	
						echo '<a href="broadcast-view.php?brID=',$rowb[0],'" class="list-group-item">' ;
						echo '<i class="fa fa-comment fa-fw"></i> ',$rowb[2],':',$rowb[1],'...' ;
						echo '<span class="pull-right text-muted small"><em>',$rowb[5],' from ',$userb[0],'</em></span></a>';
						}
						?>
                          
                            </div>
					

<?php
include('footer.php');
?>